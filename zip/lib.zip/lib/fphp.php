<?php
session_start();
include("conexion.php");
connect();
extract($_POST);
extract($_GET);
//	---------------------------------
?>